# Bank Management System (Java)

A console-based banking application demonstrating core OOP principles.

## Features
- Savings accounts (minimum balance rule, interest) and Current accounts (overdraft)
- Deposit, withdraw, transfer between accounts
- Transaction history / statement per account
- Custom exception handling (`InsufficientFundsException`)

## OOP concepts shown
Abstraction (`Account`), inheritance, polymorphism (`canWithdraw`), encapsulation, enums, collections, custom exceptions.

## Build & run (JDK 17+)
```
mkdir out
javac -d out src/bank/*.java
java -cp out bank.Main
```

## Run tests
```
javac -d out src/bank/*.java test/BankTests.java
java -cp out BankTests
```
