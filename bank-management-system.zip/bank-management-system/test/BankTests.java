import bank.*;

public class BankTests {
    static int passed = 0, failed = 0;

    static void check(String name, boolean cond) {
        if (cond) { passed++; System.out.println("PASS  " + name); }
        else { failed++; System.out.println("FAIL  " + name); }
    }

    public static void main(String[] args) throws Exception {
        Bank bank = new Bank();
        Account s = bank.openSavings("Asha", 1000);
        Account c = bank.openCurrent("Ravi", 200);

        s.deposit(500);
        check("deposit increases balance", s.getBalance() == 1500);

        s.withdraw(1400);
        check("savings keeps minimum balance of 100", s.getBalance() == 100);

        boolean threw = false;
        try { s.withdraw(1); } catch (InsufficientFundsException e) { threw = true; }
        check("savings blocks withdrawal below minimum", threw);

        c.withdraw(600);
        check("current allows overdraft up to 500", c.getBalance() == -400);

        threw = false;
        try { c.withdraw(200); } catch (InsufficientFundsException e) { threw = true; }
        check("current blocks beyond overdraft", threw);

        s.deposit(400);
        bank.transfer(s.getAccountNumber(), c.getAccountNumber(), 300);
        check("transfer debits sender", s.getBalance() == 200);
        check("transfer credits receiver", c.getBalance() == -100);
        check("transfer logs one entry per side", c.getHistory().size() == 2 && s.getHistory().size() == 4);

        threw = false;
        try { s.deposit(-5); } catch (IllegalArgumentException e) { threw = true; }
        check("negative deposit rejected", threw);

        System.out.println("\n" + passed + " passed, " + failed + " failed");
        if (failed > 0) System.exit(1);
    }
}
