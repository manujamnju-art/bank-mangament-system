package bank;

public class SavingsAccount extends Account {
    private static final double MIN_BALANCE = 100.0;
    private final double interestRate;

    public SavingsAccount(String number, String owner, double opening, double interestRate) {
        super(number, owner, opening);
        this.interestRate = interestRate;
    }

    @Override
    protected boolean canWithdraw(double amount) {
        return balance - amount >= MIN_BALANCE;
    }

    public void addInterest() {
        deposit(balance * interestRate / 100);
    }

    @Override
    public String getAccountType() { return "Savings"; }
}
