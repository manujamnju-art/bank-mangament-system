package bank;

public class CurrentAccount extends Account {
    private final double overdraftLimit;

    public CurrentAccount(String number, String owner, double opening, double overdraftLimit) {
        super(number, owner, opening);
        this.overdraftLimit = overdraftLimit;
    }

    @Override
    protected boolean canWithdraw(double amount) {
        return balance - amount >= -overdraftLimit;
    }

    @Override
    public String getAccountType() { return "Current"; }
}
