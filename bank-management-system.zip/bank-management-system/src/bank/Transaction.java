package bank;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Transaction {
    public enum Type { DEPOSIT, WITHDRAW, TRANSFER_IN, TRANSFER_OUT }

    private final Type type;
    private final double amount;
    private final LocalDateTime time = LocalDateTime.now();

    public Transaction(Type type, double amount) {
        this.type = type;
        this.amount = amount;
    }

    public Type getType() { return type; }
    public double getAmount() { return amount; }

    @Override
    public String toString() {
        return String.format("%s | %-12s | %10.2f", time.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")), type, amount);
    }
}
