package bank;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Bank bank = new Bank();
        Scanner in = new Scanner(System.in);
        System.out.println("=== Bank Management System ===");
        while (true) {
            System.out.println("\n1) Open savings  2) Open current  3) Deposit  4) Withdraw");
            System.out.println("5) Transfer  6) Statement  7) List accounts  0) Exit");
            System.out.print("Choose: ");
            String choice = in.hasNextLine() ? in.nextLine().trim() : "0";
            try {
                switch (choice) {
                    case "1" -> {
                        System.out.print("Owner: "); String o = in.nextLine();
                        System.out.print("Opening balance: "); double b = Double.parseDouble(in.nextLine());
                        System.out.println("Created " + bank.openSavings(o, b));
                    }
                    case "2" -> {
                        System.out.print("Owner: "); String o = in.nextLine();
                        System.out.print("Opening balance: "); double b = Double.parseDouble(in.nextLine());
                        System.out.println("Created " + bank.openCurrent(o, b));
                    }
                    case "3" -> {
                        System.out.print("Account no: "); Account a = bank.find(in.nextLine().trim());
                        System.out.print("Amount: "); a.deposit(Double.parseDouble(in.nextLine()));
                        System.out.println(a);
                    }
                    case "4" -> {
                        System.out.print("Account no: "); Account a = bank.find(in.nextLine().trim());
                        System.out.print("Amount: "); a.withdraw(Double.parseDouble(in.nextLine()));
                        System.out.println(a);
                    }
                    case "5" -> {
                        System.out.print("From: "); String f = in.nextLine().trim();
                        System.out.print("To: "); String t = in.nextLine().trim();
                        System.out.print("Amount: "); bank.transfer(f, t, Double.parseDouble(in.nextLine()));
                        System.out.println("Transfer complete.");
                    }
                    case "6" -> {
                        System.out.print("Account no: "); Account a = bank.find(in.nextLine().trim());
                        System.out.println(a);
                        a.getHistory().forEach(System.out::println);
                    }
                    case "7" -> bank.all().forEach(System.out::println);
                    case "0" -> { System.out.println("Goodbye!"); return; }
                    default -> System.out.println("Invalid option.");
                }
            } catch (InsufficientFundsException | IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }
}
