package bank;

import java.util.HashMap;
import java.util.Map;

public class Bank {
    private final Map<String, Account> accounts = new HashMap<>();
    private int nextId = 1001;

    public Account openSavings(String owner, double opening) {
        Account a = new SavingsAccount("SAV" + nextId++, owner, opening, 4.0);
        accounts.put(a.getAccountNumber(), a);
        return a;
    }

    public Account openCurrent(String owner, double opening) {
        Account a = new CurrentAccount("CUR" + nextId++, owner, opening, 500.0);
        accounts.put(a.getAccountNumber(), a);
        return a;
    }

    public Account find(String number) {
        Account a = accounts.get(number);
        if (a == null) throw new IllegalArgumentException("Account not found: " + number);
        return a;
    }

    public void transfer(String from, String to, double amount) throws InsufficientFundsException {
        Account src = find(from);
        Account dst = find(to);
        src.transferOut(amount);
        dst.transferIn(amount);
    }

    public Iterable<Account> all() { return accounts.values(); }
}
