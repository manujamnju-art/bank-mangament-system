package bank;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public abstract class Account {
    private final String accountNumber;
    private final String owner;
    protected double balance;
    private final List<Transaction> history = new ArrayList<>();

    protected Account(String accountNumber, String owner, double openingBalance) {
        if (openingBalance < 0) throw new IllegalArgumentException("Opening balance cannot be negative");
        this.accountNumber = accountNumber;
        this.owner = owner;
        this.balance = openingBalance;
    }

    public void deposit(double amount) {
        if (amount <= 0) throw new IllegalArgumentException("Deposit must be positive");
        balance += amount;
        history.add(new Transaction(Transaction.Type.DEPOSIT, amount));
    }

    public void withdraw(double amount) throws InsufficientFundsException {
        if (amount <= 0) throw new IllegalArgumentException("Withdrawal must be positive");
        if (!canWithdraw(amount)) throw new InsufficientFundsException("Insufficient funds in " + accountNumber);
        balance -= amount;
        history.add(new Transaction(Transaction.Type.WITHDRAW, amount));
    }

    /** Each account type decides its own withdrawal rule (polymorphism). */
    protected abstract boolean canWithdraw(double amount);

    public abstract String getAccountType();

    /** Used by Bank.transfer: moves money and logs a single TRANSFER entry. */
    void transferOut(double amount) throws InsufficientFundsException {
        if (amount <= 0) throw new IllegalArgumentException("Transfer must be positive");
        if (!canWithdraw(amount)) throw new InsufficientFundsException("Insufficient funds in " + accountNumber);
        balance -= amount;
        history.add(new Transaction(Transaction.Type.TRANSFER_OUT, amount));
    }

    void transferIn(double amount) {
        balance += amount;
        history.add(new Transaction(Transaction.Type.TRANSFER_IN, amount));
    }

    public String getAccountNumber() { return accountNumber; }
    public String getOwner() { return owner; }
    public double getBalance() { return balance; }
    public List<Transaction> getHistory() { return Collections.unmodifiableList(history); }

    @Override
    public String toString() {
        return String.format("%s [%s] %s - Balance: %.2f", getAccountType(), accountNumber, owner, balance);
    }
}
